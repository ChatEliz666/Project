//---------------------------------------------------------------------------

#pragma hdrstop

#include "Circle.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)

 Circle::Circle(double val_a, double val_b, double val_c)
 {
	a = val_a;
	b = val_b;
	c =  val_c;

	R_cl = sqrt((((((a+b+c)/2 - a)))*(((a+b+c)/2 - b))*(((a+b+c)/2 - c))));
 }

	double  Circle::GetR()
	{
	 R_cl = sqrt((((((a+b+c)/2 - a)))*(((a+b+c)/2 - b))*(((a+b+c)/2 - c))));
   return R_cl;

   }
	double  Circle::CircleSq(double R_val)
	{

	  return 3.1457*R_val*R_val;

	}
	double  Circle::CircleSq()
	{

	  return 3.1457*R_cl*R_cl;

	}








