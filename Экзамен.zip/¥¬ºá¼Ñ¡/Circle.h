//---------------------------------------------------------------------------

#ifndef CircleH
#define CircleH
 class Circle
 {
	 public:

	 Circle(double a, double b, double c);

	double GetR();
	double CircleSq();
	double CircleSq(double R_val);

	 private:

	double a;
	double b;
	double c;

	double R_cl;

 };
 //---------------------------------------------------------------------------
#endif
