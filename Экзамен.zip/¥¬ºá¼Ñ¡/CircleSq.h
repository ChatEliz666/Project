//---------------------------------------------------------------------------

#ifndef CircleSqH
#define CircleSqH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.jpeg.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.Buttons.hpp>
//---------------------------------------------------------------------------
class T�ircle : public TForm
{
__published:	// IDE-managed Components
	TImage *ImageCircle;
	TLabel *LabelMain;
	TLabel *LabelA;
	TLabel *LabelB;
	TLabel *Label�;
	TEdit *Edit1;
	TEdit *Edit2;
	TEdit *Edit3;
	TButton *Result;
	TLabel *LabelR;
	TMainMenu *MainMenu1;
	TMenuItem *N1;
	TLabel *Label1;
	void __fastcall N1Click(TObject *Sender);
	void __fastcall EditChange(TObject *Sender);
	void __fastcall ResultClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall T�ircle(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE T�ircle *�ircle;
//---------------------------------------------------------------------------
#endif
