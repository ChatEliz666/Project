//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
 #include "Circle.h"
#include "CircleSq.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
T�ircle *�ircle;
//---------------------------------------------------------------------------
__fastcall T�ircle::T�ircle(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall T�ircle::N1Click(TObject *Sender)
{
 �ircle->Close();
}
//---------------------------------------------------------------------------
void __fastcall T�ircle::EditChange(TObject *Sender)
{
	 if (!Edit1 ->Text.IsEmpty() && !Edit2 ->Text.IsEmpty() && !Edit3 ->Text.IsEmpty())
		Result->Enabled = true;
	 else
		Result->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall T�ircle::ResultClick(TObject *Sender)
{
  double a = Edit1->Text.ToDouble();
  double b = Edit2->Text.ToDouble();
  double c = Edit3->Text.ToDouble();


//Circle rad (R);
//Edit4-> Text =  FloatToStr(rad.GetR());

//double R = sqrt((((((a+b+c)/2 - a)))*(((a+b+c)/2 - b))*(((a+b+c)/2 - c))));

Circle circle(a,b,c);

	double R = circle.GetR();
	double S = circle.CircleSq();


LabelR->Caption = "R ����� " + FloatToStr(R) + "\t������� �����:" + FloatToStr(S);

int z = 0;
z = 0;
}
//---------------------------------------------------------------------------
