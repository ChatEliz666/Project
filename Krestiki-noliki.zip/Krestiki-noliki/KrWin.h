//---------------------------------------------------------------------------

#ifndef KrWinH
#define KrWinH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TWinFormK : public TForm
{
__published:	// IDE-managed Components
	TButton *ExitButton;
	TStaticText *StaticText;
	void __fastcall ExitButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TWinFormK(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWinFormK *WinFormK;
//---------------------------------------------------------------------------
#endif
