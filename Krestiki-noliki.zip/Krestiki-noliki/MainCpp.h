//---------------------------------------------------------------------------

#ifndef MainCppH
#define MainCppH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
	TButton *B1;
	TButton *B2;
	TButton *B3;
	TButton *B4;
	TButton *B5;
	TButton *B6;
	TButton *B7;
	TButton *B8;
	TButton *B9;
	TMainMenu *MainMenu;
	TMenuItem *Menu1;
	TMenuItem *Info1;
	TMenuItem *Exit1;
	TTimer *TimerWin;
	TButton *Button1;
	void __fastcall Info1Click(TObject *Sender);
	void __fastcall Exit1Click(TObject *Sender);
	void __fastcall B1Click(TObject *Sender);
	void __fastcall B2Click(TObject *Sender);
	void __fastcall B3Click(TObject *Sender);
	void __fastcall B4Click(TObject *Sender);
	void __fastcall B5Click(TObject *Sender);
	void __fastcall B6Click(TObject *Sender);
	void __fastcall B7Click(TObject *Sender);
	void __fastcall B8Click(TObject *Sender);
	void __fastcall B9Click(TObject *Sender);
	void __fastcall TimerWinTimer(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
