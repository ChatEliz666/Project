//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "NoWin.h"
#include "MainCpp.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWinFormN *WinFormN;
//---------------------------------------------------------------------------
__fastcall TWinFormN::TWinFormN(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWinFormN::ExitButtonClick(TObject *Sender)
{
	MainForm -> Close();
}
//---------------------------------------------------------------------------
