//---------------------------------------------------------------------------

#ifndef InfoCppH
#define InfoCppH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TInfoForm : public TForm
{
__published:	// IDE-managed Components
	TButton *OkButton;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	void __fastcall OkButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TInfoForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TInfoForm *InfoForm;
//---------------------------------------------------------------------------
#endif
