//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "KrWin.h"
#include "MainCpp.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TWinFormK *WinFormK;
//---------------------------------------------------------------------------
__fastcall TWinFormK::TWinFormK(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TWinFormK::ExitButtonClick(TObject *Sender)
{
    MainForm -> Close();
}
//---------------------------------------------------------------------------
