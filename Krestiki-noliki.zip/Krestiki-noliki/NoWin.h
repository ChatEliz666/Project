//---------------------------------------------------------------------------

#ifndef NoWinH
#define NoWinH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
class TWinFormN : public TForm
{
__published:	// IDE-managed Components
	TButton *ExitButton;
	TStaticText *StaticText1;
	void __fastcall ExitButtonClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TWinFormN(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TWinFormN *WinFormN;
//---------------------------------------------------------------------------
#endif
