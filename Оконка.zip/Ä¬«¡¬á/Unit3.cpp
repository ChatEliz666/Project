//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "Unit4.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::N2Click(TObject *Sender)
{
Form4 -> Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm3::N3Click(TObject *Sender)
{
Form3 -> Close();
}
//---------------------------------------------------------------------------}
//---------------------------------------------------------------------------

void __fastcall TForm3::RadioButton1Click(TObject *Sender)
{
Image1->Picture->Bitmap = NULL;
 //os x
Image1->Canvas->MoveTo(20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2-5);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2+6);

//tick x
for (int i=Image1->Width/2; i<Image1->Width-30; i+=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }
for (int i=Image1->Width/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }

//os y
Image1->Canvas->MoveTo(Image1->Width/2,Image1->Height-20);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2-5,20+5);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2+6,20+6);

//tick y
for (int i=Image1->Height/2; i<Image1->Height-30; i+=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }
for (int i=Image1->Height/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }

//������

int y = 10000;
int x = -100;

Image1->Canvas->Pen->Width = 2;
Image1->Canvas->MoveTo(x+Image1->Width/2,-y/20+Image1->Height/2);
for (x=-100; x<100; x++){
	y=x*x;
	Image1->Canvas->LineTo(x+Image1->Width/2,-y/20+Image1->Height/2);
	}
Image1->Canvas->Pen->Width = 1;

}
//---------------------------------------------------------------------------

void __fastcall TForm3::RadioButton2Click(TObject *Sender)
{
   Image1->Picture->Bitmap = NULL;

//os x

Image1->Canvas->MoveTo(20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2-5);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2+6);

//tick x
for (int i=Image1->Width/2; i<Image1->Width-30; i+=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }
for (int i=Image1->Width/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }

//os y
Image1->Canvas->MoveTo(Image1->Width/2,Image1->Height-20);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2-5,20+5);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2+6,20+6);

//tick y
for (int i=Image1->Height/2; i<Image1->Height-30; i+=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }
for (int i=Image1->Height/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }

//������

int y = 10000;
int x = -100;

Image1->Canvas->Pen->Width = 2;
Image1->Canvas->MoveTo(x+Image1->Width/10,-y/127+Image1->Height/10);
for (x=0; x<100; x++){
	y=x;
	Image1->Canvas->LineTo(x+Image1->Width/1,-y/1+Image1->Height/1);
	}
Image1->Canvas->Pen->Width = 1;
}
//---------------------------------------------------------------------------


void __fastcall TForm3::Label1Click(TObject *Sender)
{
	if(RadioButton1->Checked) RadioButton1Click(Sender);
	else if(RadioButton2->Checked) RadioButton2Click(Sender);
    else if(RadioButton3->Checked) RadioButton3Click(Sender);
	else
	{
		Label1->Caption = "�������� ������� �������!";
	}
}
//---------------------------------------------------------------------------



void __fastcall TForm3::RadioButton3Click(TObject *Sender)
{
  Image1->Picture->Bitmap = NULL;

  Image1->Canvas->Pen->Width = 2;
//������
//Image1->Canvas->Ellipse(90,90,290,290);
   int radius = 50;
   int posX = 152;
   int posY= 110;
   Image1->Canvas->Ellipse(TRect(posX-radius, posY-radius, posX+radius, posY+radius));
   ReleaseDC(Handle, Canvas->Handle);

   Image1->Canvas->Pen->Width = 1;
  //os x
Image1->Canvas->MoveTo(20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2-5);
Image1->Canvas->LineTo(Image1->Width-20,Image1->Height/2);
Image1->Canvas->LineTo(Image1->Width-20-5,Image1->Height/2+6);

//tick x
for (int i=Image1->Width/2; i<Image1->Width-30; i+=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }
for (int i=Image1->Width/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(i,Image1->Height/2-3);
	 Image1->Canvas->LineTo(i,Image1->Height/2+3);
	 }

//os y
Image1->Canvas->MoveTo(Image1->Width/2,Image1->Height-20);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2-5,20+5);
Image1->Canvas->LineTo(Image1->Width/2,20);
Image1->Canvas->LineTo(Image1->Width/2+6,20+6);

//tick y
for (int i=Image1->Height/2; i<Image1->Height-30; i+=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }
for (int i=Image1->Height/2; i>30; i-=20){
	 Image1->Canvas->MoveTo(Image1->Width/2-3,i);
	 Image1->Canvas->LineTo(Image1->Width/2+3,i);
	 }


}

//---------------------------------------------------------------------------

void __fastcall TForm3::Image1Click(TObject *Sender)
{
//Image1->Canvas->Brush->Color=clCream;
//Image1->Canvas->FillRect(Rect(500,600,281,281));
}
//---------------------------------------------------------------------------


